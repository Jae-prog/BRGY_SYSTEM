<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Barangay Information System</title>
  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="style/style.css">
</head>
<body>
<header>
  <img src="logo/logo.png">
  <div>
    <h1>Barangay Information System</h1>
    <p>Republic of the Philippines</p>
  </div>
  <button class="toggle" onclick="toggleDark()">🌙 Dark</button>
</header>

<div id="sidebar">
  <button onclick="show('dashboard')">
    <i class="fa-solid fa-chart-line"></i> Dashboard
  </button>
  <button onclick="show('services')">
    <i class="fa-solid fa-file-lines"></i> Services
  </button>
  <button onclick="show('reports')">
    <i class="fa-solid fa-bullhorn"></i> Reports
  </button>
  <button onclick="show('about')">
    <i class="fa-solid fa-circle-info"></i> About
  </button>
  <hr>
  <button onclick="openLogin()">
    <i class="fa-solid fa-user-shield"></i> Admin Login
  </button>
</div>

<div id="content">

  <!-- Dashboard -->
  <section id="dashboard" class="active">
    <div class="stats">
      <div class="stat" style="background:linear-gradient(135deg,#2563eb,#1d4ed8)">
        <i class="fa-solid fa-bullhorn"></i>
        <b id="repCount">0</b> Total Reports
      </div>
      <div class="stat" style="background:linear-gradient(135deg,#f59e0b,#facc15)">
        <i class="fa-solid fa-hourglass-half"></i>
        <b id="repPending">0</b> Pending Reports
      </div>
      <div class="stat" style="background:linear-gradient(135deg,#16a34a,#22c55e)">
        <i class="fa-solid fa-check-circle"></i>
        <b id="repResolved">0</b> Resolved Reports
      </div>
      <div class="stat stat-res">
        <i class="fa-solid fa-users"></i>
        <b id="resCount">0</b> Residents
      </div>
      <div class="stat stat-req">
        <i class="fa-solid fa-clock"></i>
        <b id="reqCount">0</b> Pending Requests
      </div>
      <div class="stat stat-app">
        <i class="fa-solid fa-circle-check"></i>
        <b id="appCount">0</b> Approved
      </div>
    </div>

    <div class="card">
      <h3>Announcements</h3>
      <div id="annList"></div>
    </div>

    <div class="card">
      <h3>Barangay Officials</h3>
      <table>
        <thead>
          <tr><th>Name</th><th>Position</th><th>Birthdate</th><th>Age</th><th>Term</th></tr>
        </thead>
        <tbody id="officialsTable"></tbody>
      </table>
    </div>
  </section>

  <!-- Services -->
  <section id="services">
    <div class="card">
      <h3>Service Request</h3>
      <form onsubmit="submitService(event)">
        <input id="ln" placeholder="Last Name" required>
        <input id="fn" placeholder="First Name" required>
        <input id="mn" placeholder="Middle Name" required>
        <input id="saddr" placeholder="Address" required>
        <input id="purpose" placeholder="Purpose / Reason" required>
        <select id="stype" required>
          <option value="">Select Service</option>
          <option>Barangay Clearance</option>
          <option>Barangay ID</option>
          <option>Cedula</option>
        </select>
        <button class="primary">Submit Request</button>
      </form>

      <h4>My Requests</h4>
      <table>
        <thead><tr><th>Service</th><th>Status</th><th>Control #</th></tr></thead>
        <tbody id="myReqTable"></tbody>
      </table>
    </div>
  </section>

  <!-- Reports -->
  <section id="reports">
    <div class="card">
      <h3>Community Concern</h3>
      <form onsubmit="sendConcern(event)">
        <input id="caddr" placeholder="Address" required>
        <textarea id="cmsg" placeholder="Concern..." required></textarea>
        <input type="file" id="cimg" accept="image/*">
        <button class="primary">Send</button>
      </form>

      <h4 style="margin-top:25px;">My Reports</h4>
      <table>
        <thead>
          <tr><th>Address</th><th>Concern</th><th>Status</th></tr>
        </thead>
        <tbody id="myReportTable"></tbody>
      </table>
    </div>
  </section>

  <!-- About -->
  <section id="about">
    <div class="card">
      <h3>About Barangay</h3>
      <p>Hotline: 09123456789</p>
    </div>
  </section>

  <!-- Admin -->
  <section id="admin">
    <div class="card">
      <h3>Add Announcement</h3>
      <input id="atitle" placeholder="Title">
      <textarea id="acontent" placeholder="Context"></textarea>
      <button class="primary" onclick="postAnn()">Post</button>
    </div>

    <div class="card">
      <h3>Posted Announcements</h3>
      <div id="annAdminList"></div>
    </div>

    <div class="card">
      <h3>Residents</h3>
      <form onsubmit="addResident(event)">
        <div class="form-grid">
          <input id="r_lname" placeholder="Last Name" required>
          <input id="r_fname" placeholder="First Name" required>
          <input id="r_mname" placeholder="Middle Name">
          <div>
            <label>Birthdate</label>
            <input type="date" id="r_bd" required>
          </div>
          <select id="r_gender" required>
            <option value="">Gender</option>
            <option>Male</option>
            <option>Female</option>
          </select>
          <select id="r_status" required>
            <option value="">Civil Status</option>
            <option>Single</option>
            <option>Married</option>
            <option>Widowed</option>
            <option>Separated</option>
          </select>
          <input id="r_addr" placeholder="Complete Address" required>
          <input id="r_contact" placeholder="Contact Number" required>
        </div>
        <button class="primary" type="submit">Add Resident</button>
      </form>

      <br>
      <input placeholder="Search resident..." oninput="searchResidents(this.value)">
      <table>
        <thead>
          <tr>
            <th>Name</th><th>Birthdate</th><th>Gender</th><th>Status</th><th>Address</th><th>Contact</th><th>Action</th>
          </tr>
        </thead>
        <tbody id="resTable"></tbody>
      </table>
    </div>

    <!-- Service Requests Table -->
    <div class="card">
      <h3>Service Requests</h3>
      <table>
        <thead><tr><th>Name</th><th>Service</th><th>Purpose</th><th>Address</th><th>Action</th></tr></thead>
        <tbody id="reqTable"></tbody>
      </table>
    </div>

    <!-- Approved Requests -->
    <div class="card">
      <h3>Approved Requests</h3>
      <table>
        <thead><tr><th>Name</th><th>Service</th><th>Control #</th><th>Status</th></tr></thead>
        <tbody id="approvedTable"></tbody>
      </table>
    </div>

    <!-- Residents Reports -->
    <div class="card">
      <h3>Residents Reports</h3>
      <table>
        <thead><tr><th>Address</th><th>Concern</th><th>Image</th><th>Status</th><th>Action</th></tr></thead>
        <tbody id="reportTable"></tbody>
      </table>
    </div>

    <button class="danger" onclick="logout()">Logout</button>
  </section>

</div>

<!-- Login Modal -->
<div class="modal" id="loginModal">
  <div class="modal-box">
    <span class="close" onclick="loginModal.classList.remove('show')">✖</span>
    <h3>Admin Login</h3>
    <div class="login-form">
      <input id="email" placeholder="Username">
      <div class="password-group">
        <input id="pass" type="password" placeholder="Password">
        <div class="show-password">
          <input type="checkbox" id="showPass">
          <span>Show password</span>
        </div>
      </div>
      <button class="primary" onclick="login()">Login</button>
    </div>
  </div>
</div>

<script src="js/script.js"></script>
</body>
</html>
